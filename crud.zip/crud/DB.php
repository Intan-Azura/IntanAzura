<?php
  $koneksi=mysqli_connect('localhost','root','','dbperpustakaan4c')or die('Database tidak ditemukan');
  //jalankan url: localhost/si4c/DB.php
  //jika tampilan kosong, artinya koneksi berhasil
  ?>