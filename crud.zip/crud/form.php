<form action="insert.php" method="post">
    Nim : <br>
    <input type="text" name="nim" id="">
    <br>
    nama : <br>
    <input type="text" name="nama" id="">
    <br>
    alamat : <br>
    <input type="text" name="alamat" id="">
    <br>
    jkl : <br>
    <select name="jkl" id="">
        <option value="PRIA">PRIA</option>
        <option value="WANITA">WANITA</option>
    </select>
    <br>
    agama : <br>
    <select name="agama" id="">
        <option value="ISLAM">ISLAM</option>
        <option value="KRISTEN PROSTESTAN">KRISTEN PROSTESTAN</option>
        <option value="KRISTEN KHATOLIK">KRISTEN KHATOLIK</option>
        <option value="HINDU">HINDU</option>
        <option value="BUDHA">BUDHA</option>
        <option value="KHONG HU CU">KHONG HU CU</option>
    </select>
    <br>
    email : <br>
    <input type="text" name="email" id="">
    <br>
    pwd : <br>
    <input type="text" name="pwd" id="">
    <br>
    <button type="submit">Simpan Data</button>
</form>